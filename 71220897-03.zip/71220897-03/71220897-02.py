print('Input angka dadu 1 - 6')
# input
dadu1 = int(input('Dadu 1 : '))
dadu2 = int(input('Dadu 2 : '))
dadu3 = int(input('Dadu 3 : '))

#proses
if dadu1 + dadu2 + dadu3 == 18:
    print('Royal')
elif dadu1 == dadu2 and dadu1 == dadu3:
    print('Triple')
elif dadu1 == 4 and dadu2 == 5 and dadu3 == 6:
    print('Flush')
elif dadu1 == dadu2 or dadu2 == dadu3 or dadu1 == dadu3:
    print('Double')
else:
    print('Single')