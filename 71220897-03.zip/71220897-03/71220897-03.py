# Input nilai dari ketiga pemain
nilai_pemain1 = int(input("Masukkan nilai pemain 1: "))
nilai_pemain2 = int(input("Masukkan nilai pemain 2: "))
nilai_pemain3 = int(input("Masukkan nilai pemain 3: "))

# proses
if nilai_pemain1 <= 21 or nilai_pemain2 <= 21 or nilai_pemain3 <= 21:
    if nilai_pemain1 == 21:
        print("Pemenangnya adalah pemain 1")
    elif nilai_pemain2 == 21:
        print("Pemenangnya adalah pemain 2")
    elif nilai_pemain3 == 21:
        print("Pemenangnya adalah pemain 3")
    else:
        selisih_pemain1 = abs(nilai_pemain1 - 21)
        selisih_pemain2 = abs(nilai_pemain2 - 21)
        selisih_pemain3 = abs(nilai_pemain3 - 21)
        if selisih_pemain1 < selisih_pemain2 and selisih_pemain1 < selisih_pemain3:
            print("Pemenangnya adalah pemain 1")
        elif selisih_pemain2 < selisih_pemain1 and selisih_pemain2 < selisih_pemain3:
            print("Pemenangnya adalah pemain 2")
        elif selisih_pemain3 < selisih_pemain1 and selisih_pemain3 < selisih_pemain2:
            print("Pemenangnya adalah pemain 3")
        else:
            print("Tidak ada pemenang")
else:
    print("Tidak ada pemenang")