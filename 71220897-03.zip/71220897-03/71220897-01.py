jarak = int(input('Masukan Jarak : '))
batas_a = int(input('Masukan Batas Nilai A : '))
nilai = int(input('Masukan Nilai : '))

nilai_amin = batas_a - jarak
nilai_bplus = nilai_amin - jarak
nilai_b = nilai_bplus - jarak
nilai_bmin = nilai_b - jarak
nilai_cplus = nilai_bmin - jarak
nilai_c = nilai_cplus - jarak
nilai_d = nilai_c - jarak
nilai_e = nilai_d - jarak

if nilai >= batas_a:
    print('A')
elif nilai >= nilai_amin:
    print('A-')
elif nilai >= nilai_bplus:
    print('B+')
elif nilai >= nilai_b:
    print('B')
elif nilai >= nilai_bmin:
    print('B-')
elif nilai >= nilai_cplus:
    print('C+')
elif nilai >= nilai_c:
    print('C')
elif nilai >= nilai_d:
    print('D')
else:
    print('E')