# Input
jarak = int(input("Masukkan jarak antar batas nilai: "))
batas_a = int(input("Masukkan nilai minimum untuk mendapat A: "))

# proses
nilai = 100
nilai_huruf = []
while nilai >= 0:
    if nilai >= batas_a:
        nilai_huruf.append("A")
    elif nilai >= batas_a - jarak:
        nilai_huruf.append("A-")
    elif nilai >= batas_a - 2*jarak:
        nilai_huruf.append("B+")
    elif nilai >= batas_a - 3*jarak:
        nilai_huruf.append("B")
    elif nilai >= batas_a - 4*jarak:
        nilai_huruf.append("B-")
    elif nilai >= batas_a - 5*jarak:
        nilai_huruf.append("C+")
    elif nilai >= batas_a - 6*jarak:
        nilai_huruf.append("C")
    elif nilai >= batas_a - 7*jarak:
        nilai_huruf.append("D")
    else:
        nilai_huruf.append("E")
    nilai -= jarak

# Input
nilai_input = int(input("Masukkan nilai anda: "))

# proses
if nilai_input >= batas_a:
    print("Nilai anda adalah A")
elif nilai_input >= batas_a - jarak:
    print("Nilai anda adalah A-")
elif nilai_input >= batas_a - 2*jarak:
    print("Nilai anda adalah B+")
elif nilai_input >= batas_a - 3*jarak:
    print("Nilai anda adalah B")
elif nilai_input >= batas_a - 4*jarak:
    print("Nilai anda adalah B-")
elif nilai_input >= batas_a - 5*jarak:
    print("Nilai anda adalah C+")
elif nilai_input >= batas_a - 6*jarak:
    print("Nilai anda adalah C")
elif nilai_input >= batas_a - 7*jarak:
    print("Nilai anda adalah D")
else:
    print("Nilai anda adalah E")